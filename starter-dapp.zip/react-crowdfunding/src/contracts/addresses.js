const addresses = {
  "crowdfunding_testnet": "erd1qqqqqqqqqqqqqpgqhf8qase6a8nw8phjwm2wd7uvkutexk67d8sszf9xuu"
};

export default addresses;
