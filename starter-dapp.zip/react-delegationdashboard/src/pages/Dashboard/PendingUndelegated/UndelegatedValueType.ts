export class UndelegatedValueType {
  value: string;
  timeLeft: number;
  public constructor(value: string, timeLeft: number) {
    this.value = value;
    this.timeLeft = timeLeft;
  }
}
