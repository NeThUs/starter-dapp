const txStatus = {
  pending: 'Pending',
  notExecuted: 'Not Executed',
  invalid: 'Invalid',
  success: 'Success',
  fail: 'Fail',
};

export default txStatus;
